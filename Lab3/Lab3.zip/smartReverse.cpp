/* 
 * File: smartReverse.cpp
 * Purpose: provide the implementation of the smartReverse class
 *
 * Author: Yueqi Li
 *
 */

#include <stack>
#include "smartReverse.h"
using namespace std;

// default constructor
smartReverse::smartReverse()
{
    // you do not really need to do anything
    // since string class provides default constructor 
    // to initialize the object to empty string
}

// constructor: initialize str with ini_str passing as a parameter
smartReverse::smartReverse(string ini_str)
{
	str=ini_str;
}

// return the current value of the private data member: str
string smartReverse::getString() const
{
	return str;
}

// set the value of str to be the passed in parameter input_str
void smartReverse::setString(string input_str)
{
	str=input_str;
}

// return a reversed string from str
// using a loop to implement
// Note that str has not been changed
string smartReverse::rev() const
{
	int size=str.length();
	if(size<=1)
		return str;
	else{
		string res="";
		for(int i=size-1;i>=0;i--)
			res+=str.substr(i,1);
		return res;
	}
}
// return a reversed string from str
// using recursion to implement
// Note that str has not been changed
string smartReverse::rev_recursive() const
{
	int size=str.length();
	if(size<=1)
                return str;
	else{
			
		string res = str.substr(1,str.length()-1);
		
		smartReverse smallsmart(res);
	
		return (smallsmart.rev_recursive() + str[0]);
		

	
}
}

// return a reversed string from str
// using a stack to implement
// Note that str has not been changed
string smartReverse::rev_stack() const
{
	int size=str.length();
        if(size<=1)
                return str;
        else{
                string res=str;
		stack<char> st;
		for(int i=0;i<size;i++)
			st.push(res[i]);
		for(int j=0;j<size;j++){
			res[j]=st.top();
			st.pop();
		}
		return res;
	}
}

